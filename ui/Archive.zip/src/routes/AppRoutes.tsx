import { Route, Routes } from "react-router-dom";
import AuthLayout from "../layouts/AuthLayout";
import HomeLayout from "../layouts/HomeLayout";
import CustomerDetails from "../pages/customers/CustomerDetails";
import CustomerList from "../pages/customers/CustomerList";
import Dashboard from "../pages/dashboard/Dashboard";
import Home from "../pages/home/Home";
import ProtectedRoute from "./ProtectedRoute";
import { RoutePaths } from "./RoutePaths";

export default function AppRoutes() {
    return (
        <Routes>
            {/* Public */}
            <Route element={<HomeLayout />}>
                <Route path={RoutePaths.HOME} element={<Home />} />
            </Route>

            {/* Protected */}
            <Route element={<ProtectedRoute />}>
                <Route element={<AuthLayout />}>
                    <Route
                        path={RoutePaths.DASHBOARD}
                        element={<Dashboard />}
                    />

                    <Route path={RoutePaths.AGENT} element={<CustomerList />} />

                    <Route
                        path={RoutePaths.CUSTOMER_DETAILS}
                        element={<CustomerDetails />}
                    />
                </Route>
            </Route>
        </Routes>
    );
}
