export const RoutePaths = {
  HOME: "/",
  DASHBOARD: "/dashboard",
  AGENT: "/agent",
  CUSTOMER_DETAILS: "/customers/:id",
  POLICIES: "/policies",
  CLAIMS: "/claims",
  PAYMENTS: "/payments",
  DOCUMENTS: "/documents",
  REPORTS: "/reports",
} as const;