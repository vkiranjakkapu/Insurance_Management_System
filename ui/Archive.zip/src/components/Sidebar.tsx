import React, {
    useEffect,
    useState,
    type ForwardRefExoticComponent,
    type PropsWithoutRef,
    type ReactNode,
    type SVGProps,
} from "react";

import ProfileIcon from "../assets/undraw_finance-guy-avatar_vhop.svg";
import Icon from "/public/icon.png";

// Import the outline variants (24x24) from Heroicons v2
import {
    ArrowLeftEndOnRectangleIcon,
    Bars3Icon,
    Cog6ToothIcon,
    FolderIcon,
    HomeIcon,
    MoonIcon,
    SunIcon,
    UsersIcon,
    XMarkIcon,
} from "@heroicons/react/24/outline";
import usePrincipal from "../context/usePrincipal";

interface SidebarLayoutProps {
    children?: ReactNode;
}

interface NavItem {
    label: string;
    // Type definition for Heroicons functional components
    icon: ForwardRefExoticComponent<
        PropsWithoutRef<SVGProps<SVGSVGElement>> & {
            title?: string;
            titleId?: string;
        }
    >;
    active: boolean;
}

export default function Sidebar({
    children,
}: SidebarLayoutProps): React.JSX.Element {
    const auth = usePrincipal();

    const [isOpen, setIsOpen] = useState<boolean>(false);
    const [isDarkMode, setIsDarkMode] = useState<boolean>(() => {
        if (typeof window !== "undefined") {
            return (
                document.documentElement.classList.contains("dark") ||
                localStorage.getItem("theme") === "dark"
            );
        }
        return true;
    });

    // Sync state changes with the DOM root class
    useEffect(() => {
        if (isDarkMode) {
            document.documentElement.classList.add("dark");
            localStorage.setItem("theme", "dark");
        } else {
            document.documentElement.classList.remove("dark");
            localStorage.setItem("theme", "light");
        }
    }, [isDarkMode]);

    const toggleTheme = (): void => {
        setIsDarkMode((prev) => !prev);
    };

    const navItems: NavItem[] = [
        { label: "Dashboard", icon: HomeIcon, active: true },
        { label: "Team Members", icon: UsersIcon, active: false },
        { label: "Projects", icon: FolderIcon, active: false },
        { label: "Settings", icon: Cog6ToothIcon, active: false },
    ];

    return (
        <div className="flex h-screen w-full overflow-hidden font-sans bg-slate-50 text-slate-900 dark:bg-slate-900 dark:text-slate-100 transition-colors duration-300">
            {/* MOBILE SIDEBAR OVERLAY */}
            {isOpen && (
                <div
                    className="fixed inset-0 z-40 bg-slate-900/60 backdrop-blur-sm md:hidden"
                    onClick={() => setIsOpen(false)}
                />
            )}

            {/* SIDEBAR SIDE PANEL */}
            <aside
                className={`
        fixed inset-y-0 left-0 z-50 flex w-64 flex-col border-r p-4 transition-transform duration-300 ease-in-out
        border-slate-200 bg-white text-slate-700
        dark:border-slate-800 dark:bg-slate-950 dark:text-slate-300
        md:translate-x-0 ${isOpen ? "translate-x-0" : "-translate-x-full"}
      `}
            >
                {/* Header Brand Info */}
                <div className="flex h-12 items-center justify-between px-2">
                    <div className="flex items-center gap-3">
                        <img
                            src={Icon}
                            alt="IMS"
                            width="40px"
                            className="rounded-sm drop-shadow-sm outline-1 outline-offset-2 outline-indigo-500"
                        />
                        <span className="text-lg font-semibold tracking-wide text-slate-900 dark:text-white">
                            IMS
                        </span>
                    </div>
                    {/* Mobile Close Button */}
                    <button
                        onClick={() => setIsOpen(false)}
                        className="rounded-lg p-1.5 hover:bg-slate-100 dark:hover:bg-slate-900 md:hidden"
                        aria-label="Close menu"
                    >
                        <XMarkIcon className="h-5 w-5" />
                    </button>
                </div>

                {/* Core Navigation Items Stack */}
                <nav className="mt-6 flex-1 space-y-1">
                    <p className="px-2 text-xs font-semibold uppercase tracking-wider text-slate-400 dark:text-slate-500">
                        Workspace
                    </p>
                    {navItems.map((item, idx) => {
                        const IconComponent = item.icon;
                        return (
                            <a
                                key={idx}
                                href="#"
                                className={`flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-all group
                  ${
                      item.active
                          ? "bg-indigo-50 text-indigo-600 dark:bg-indigo-600/10 dark:text-indigo-400"
                          : "hover:bg-slate-100 text-slate-600 hover:text-slate-900 dark:text-slate-400 dark:hover:bg-slate-900 dark:hover:text-slate-100"
                  }
                `}
                            >
                                <IconComponent
                                    className={`h-5 w-5 transition-colors ${
                                        item.active
                                            ? "text-indigo-600 dark:text-indigo-400"
                                            : "text-slate-400 group-hover:text-slate-600 dark:text-slate-500 dark:group-hover:text-slate-300"
                                    }`}
                                />
                                {item.label}
                            </a>
                        );
                    })}
                </nav>

                {/* Bottom Controls / Profile Meta Panel */}
                <div className="mt-auto border-t border-slate-200 pt-4 dark:border-slate-800 space-y-3">
                    {/* Theme Toggle Utility */}
                    <button
                        onClick={toggleTheme}
                        className="flex w-full items-center justify-between rounded-lg px-3 py-2 text-sm font-medium text-slate-500 hover:bg-slate-100 hover:text-slate-900 dark:text-slate-400 dark:hover:bg-slate-900 dark:hover:text-slate-100 transition-colors"
                    >
                        <div className="flex items-center gap-3">
                            {isDarkMode ? (
                                <SunIcon className="h-5 w-5" />
                            ) : (
                                <MoonIcon className="h-5 w-5" />
                            )}
                            <span>
                                {isDarkMode ? "Light Mode" : "Dark Mode"}
                            </span>
                        </div>
                        <span className="text-xs uppercase bg-slate-200 dark:bg-slate-800 px-1.5 py-0.5 rounded text-slate-600 dark:text-slate-400 font-bold">
                            Toggle
                        </span>
                    </button>

                    {/* Profile Summary Slot */}
                    <div className="flex items-center justify-between px-2 pt-1">
                        <div className="flex items-center gap-3 min-w-0">
                            <img
                                src={ProfileIcon}
                                alt="Avatar"
                                className="h-9 w-9 rounded-full object-cover border border-slate-200 dark:border-slate-800"
                            />
                            <div className="min-w-0 flex-1">
                                <p className="truncate text-sm font-medium text-slate-900 dark:text-slate-200">
                                    {auth.principal.firstName +
                                        auth.principal.lastName}
                                </p>
                                <p className="truncate text-xs text-slate-400 dark:text-slate-500">
                                    {auth.principal.email}
                                </p>
                            </div>
                        </div>
                        <button
                            className="text-slate-400 hover:text-red-500 dark:text-slate-500 dark:hover:text-red-400 p-1.5 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-900 transition-colors"
                            aria-label="Log out"
                            onClick={() => auth.logout()}
                        >
                            <ArrowLeftEndOnRectangleIcon className="h-5 w-5" />
                        </button>
                    </div>
                </div>
            </aside>

            {/* RIGHT VIEWPORT VIEW CANVAS */}
            <div className="flex flex-1 flex-col md:pl-64 h-full w-full">
                {/* Top Sticky Header for Mobile */}
                <header className="flex h-16 items-center justify-between border-b px-4 md:hidden border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-950">
                    <img
                        src={Icon}
                        alt="IMS"
                        width="40px"
                        className="rounded-sm drop-shadow-sm outline-1 outline-offset-2 outline-indigo-500"
                    />
                    <button
                        onClick={() => setIsOpen(true)}
                        className="rounded-lg p-2 text-slate-500 hover:bg-slate-100 dark:text-slate-400 dark:hover:bg-slate-900 focus:outline-none"
                        aria-label="Open menu"
                    >
                        <Bars3Icon className="h-6 w-6" />
                    </button>
                </header>

                {/* Main Context Canvas View */}
                <main className="flex-1 p-6 overflow-y-auto">
                    {children || (
                        <>
                            <h1 className="text-2xl font-bold tracking-tight text-slate-900 dark:text-white">
                                Dashboard Workspace
                            </h1>
                        </>
                    )}
                </main>
            </div>
        </div>
    );
}
