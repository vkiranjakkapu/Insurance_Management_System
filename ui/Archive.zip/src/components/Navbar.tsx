import {
    Disclosure,
    DisclosurePanel
} from "@headlessui/react";

import Icon from "/public/icon.png";

// function classNames(...classes: string[]) {
//   return classes.filter(Boolean).join(' ')
// }
export default function Navbar() {

    return (
        <>
            <Disclosure as="nav" className="relative bg-gray-800">
                <div className="mx-auto max-w-7xl px-2 sm:px-6 lg:px-8">
                    <div className="relative flex h-16 items-center justify-around">
                        <div className="flex items-center justify-center sm:items-stretch sm:justify-start">
                            <div className="flex shrink-0 items-center gap-2 text-white">
                                <img
                                    alt="IMS"
                                    src={Icon}
                                    className="h-8 w-auto rounded-sm"
                                />
                                <span>IMS</span>
                            </div>
                        </div>
                        {/* Mobile menu button*/}
                        {/* <div className="flex items-center sm:hidden">
                            <DisclosureButton className="group relative inline-flex items-center justify-center rounded-md p-2 text-gray-400 hover:bg-white/5 hover:text-white focus:outline-2 focus:-outline-offset-1 focus:outline-indigo-500">
                                <span className="absolute -inset-0.5" />
                                <span className="sr-only">Open main menu</span>
                                <Bars3Icon
                                    aria-hidden="true"
                                    className="block size-6 group-data-open:hidden"
                                />
                                <XMarkIcon
                                    aria-hidden="true"
                                    className="hidden size-6 group-data-open:block"
                                />
                            </DisclosureButton>
                        </div> */}
                    </div>
                </div>

                <DisclosurePanel className="sm:hidden">
                    {/* <div className="space-y-1 px-2 pt-2 pb-3">
                        <DisclosureButton
                            key="{item.name}"
                            as="a"
                            href="#"
                            // aria-current={true ? "page" : undefined}
                            className={classNames(
                                // ("true" == true)
                                //     ? "bg-gray-900 text-white"
                                //     : "text-gray-300 hover:bg-white/5 hover:text-white",
                                "block rounded-md px-3 py-2 text-base font-medium text-white",
                            )}
                        >
                            Policies
                        </DisclosureButton>
                    </div> */}
                </DisclosurePanel>
            </Disclosure>
        </>
    );
}
