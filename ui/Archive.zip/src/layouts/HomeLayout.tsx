import { Navigate, Outlet } from "react-router-dom";
import Navbar from "../components/Navbar";
import usePrincipal from "../context/usePrincipal";

export default function HomeLayout() {
    const { principal, getHomeRoute } = usePrincipal();

    if (principal.isLoggedIn) {
        return <Navigate to={getHomeRoute(principal.roles)} replace />;
    }

    return (
        <>
            <Navbar />
            <Outlet />
        </>
    );
}
