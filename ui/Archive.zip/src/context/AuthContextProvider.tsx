import { useEffect, useState, type ReactNode } from "react";
import { RoutePaths } from "../routes/RoutePaths";
import AuthService, { type LoginRequest } from "../services/AuthService";
import TokenStorage from "../storage/TokenStorage";
import { decodedToken } from "../utils/JwtUtils";
import { AuthContext, type Principal } from "./usePrincipal";

const principal: Principal = {
    id: 0,
    name: "",
    email: "",
    roles: [],
    accessToken: "",
    refreshToken: "",
    isLoggedIn: false,
};

type AuthContextProviderProps = {
    children: ReactNode;
};

export default function AuthContextProvider({
    children,
}: AuthContextProviderProps) {
    console.log("AuthContext");
    
    const [authContext, setAuthContext] = useState<Principal>(principal);

    useEffect(() => {
        initializeAuthentication();
    }, []);

    async function initializeAuthentication() {
        const refreshToken = TokenStorage.getRefreshToken();

        if (!refreshToken) {
            return;
        }

        try {
            const response = await AuthService.refresh(refreshToken);
            const jwt = decodedToken(response.accessToken);

            TokenStorage.save(response.accessToken, response.refreshToken);

            setAuthContext((prev) => ({
                ...prev,
                id: jwt.uid,
                name: jwt.name,
                email: jwt.sub,
                roles: jwt.roles,
                accessToken: response.accessToken,
                refreshToken: response.refreshToken,
                isLoggedIn: true,
            }));
        } catch (error) {
            console.error(error);
            TokenStorage.clear();
            setAuthContext(principal);
        }
    }

    async function authenticate(credentials: LoginRequest): Promise<string> {
        const response = await AuthService.login(credentials);

        const jwt = decodedToken(response.accessToken);

        TokenStorage.save(response.accessToken, response.refreshToken);

        setAuthContext((prev) => ({
            ...prev,
            email: jwt.sub,
            roles: jwt.roles,
            accessToken: response.accessToken,
            refreshToken: response.refreshToken,
            isLoggedIn: true,
        }));

        return getHomeRoute(jwt.roles);
    }

    async function logout() {
        const status = await AuthService.logout(authContext.refreshToken);
        if (status == 204) {
            TokenStorage.clear();
            setAuthContext((prev) => ({
                ...prev,
                isLoggedIn: false,
            }));
        }
    }

    async function refresh() {
        const response = await AuthService.refresh(authContext.accessToken);
        TokenStorage.save(response.accessToken, response.refreshToken);
        setAuthContext((prev) => ({
            ...prev,
            accessToken: response.accessToken,
            refreshToken: response.refreshToken,
            isLoggedIn: true,
        }));
    }

    function getHomeRoute(roles: string[]) {
        if (roles.includes("ADMIN")) {
            return RoutePaths.DASHBOARD;
        }

        if (roles.includes("AGENT")) {
            return RoutePaths.AGENT;
        }

        if (roles.includes("CUSTOMER")) {
            return RoutePaths.POLICIES;
        }

        return RoutePaths.HOME;
    }

    return (
        <AuthContext
            value={{
                principal: authContext,
                authenticate,
                logout,
                refresh,
                tokenLogin: initializeAuthentication,
                getHomeRoute,
            }}
        >
            {children}
        </AuthContext>
    );
}
