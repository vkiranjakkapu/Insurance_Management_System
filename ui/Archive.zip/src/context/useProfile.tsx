import { createContext, useContext } from "react";
import type { Address } from "../services/AccountService";

export type UserProfile = {
    id: number;
    email: string;
    name: string;
    firstName: string;
    lastName: string;
    phone: string;
    address: Address;
    dob: string;
};

export type ProfileContextType = {
    profile: UserProfile | null;
    loadProfile: () => Promise<void>;
};

export const ProfileContext = createContext<ProfileContextType | null>(null);

export default function useProfile() {
    const context = useContext(ProfileContext);
    if (context == null) throw new Error("ProfileContext Null");
    return context;
}
