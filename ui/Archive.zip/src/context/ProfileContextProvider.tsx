import { useEffect, useState, type ReactNode } from "react";
import AccountService from "../services/AccountService";
import { ProfileContext, type UserProfile } from "./useProfile";

type ProfileProps = {
    children: ReactNode;
};

export default function ProfileContextProvider({ children }: ProfileProps) {
    console.log("ProfileContext");
    const [profile, setProfile] = useState<UserProfile | null>(null);

    useEffect(() => {
        if (!profile) {
            loadProfile();
        }
    }, []);

    async function loadProfile() {
        const response = await AccountService.getMyProfile(profile?.id);
        const userProfile: UserProfile = {
            ...response,
            name: response.firstName + " " + response.lastName,
        };
        setProfile(userProfile);
    }

    return (
        <ProfileContext value={{ profile, loadProfile }}>
            {children}
        </ProfileContext>
    );
}
