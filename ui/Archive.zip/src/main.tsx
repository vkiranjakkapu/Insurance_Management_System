import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import { BrowserRouter } from "react-router-dom";
import AuthContextProvider from "./context/AuthContextProvider.tsx";
import App from "./App.tsx";
import "./index.css";
import ProfileContextProvider from "./context/ProfileContextProvider.tsx";

createRoot(document.getElementById("root")!).render(
    <StrictMode>
        <AuthContextProvider>
            <ProfileContextProvider>
                <BrowserRouter>
                    <App />
                </BrowserRouter>
            </ProfileContextProvider>
        </AuthContextProvider>
    </StrictMode>,
);
