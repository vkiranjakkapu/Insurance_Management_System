import api from "../api/api";
import { AppConfig } from "../config/AppConfig";

export interface UserResponse {
    id: number;
    firstName: string;
    lastName: string;
    email: string;
    phone: string;
    address: Address;
    dob: string;
    enabled: boolean;
    roles: string[];
    createdAt: string;
    updatedAt: string;
}

export type Address = {
    id: number;
    street: string;
    pinCode: string;
    state: string;
    country: string;
    deleted: boolean;
};

class AccountService {
    async getMyProfile(id: number): Promise<UserResponse> {
        const response = await api.get(
            AppConfig.API_BASE_URL + "api/user/" + id,
        );

        if (response.status != 200) {
            console.log("Failed to fetch UserDetails");
        }

        return response.data;
    }
}

export default new AccountService();
