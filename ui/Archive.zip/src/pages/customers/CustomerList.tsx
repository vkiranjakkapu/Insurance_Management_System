export default function CustomerList() {
    return []
}